serwer w pliku serwer.ts

kompilowany komendą: 
tsc --target es5 serwer.ts

odpalany komendą: 
node serwer.js

strony pod adresem:
http://localhost:8080

serwuje strony używając szablonów ejs

pokemon.ejs  - szablon z opisem pokemona
list.ejs     - szablon z listą pokemonów

